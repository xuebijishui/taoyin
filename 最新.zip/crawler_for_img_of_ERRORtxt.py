from crawler_class import Crawler_class
import time


def crawler_for_img_of_ERRORtxt():
    
    print('请确保本程序所在目录内存在ERROR.txt')
    img_dict_file = open(r'ERROR.txt','r').readlines()
    img_list = [eval(img_dict[:-1]) for img_dict in img_dict_file]    #img_list内嵌套多个
    
    crawler = Crawler_class()
    crawler.img_amount = len(img_list)
    
    max_time = int(input("请输入尝试次数上限："))

    print('\n共有%d张目标图片\n' % crawler.img_amount)
    '''    
    for img_number, img_dict in enumerate(img_list):
        img_dict['img_number'] = img_number+1
    '''    
    for run_time in range(1, max_time+1):
            
        if run_time != 1:                    
            img_list = crawler.failed_img_list
        crawler.failed_img_list = []
                                
        for img_number, img_dict in enumerate(img_list): 
                    
            is_successful = crawler.get_and_save_img(img_dict, run_time)
            
            if is_successful:    
                crawler.remove_successful_img_from_ERRORtxt(img_dict)
                
        if crawler.failed_img_list:
            print('%d张图片下载失败：' % len(crawler.failed_img_list))
            for failed_img_dict in crawler.failed_img_list:
                print('贴子%s-图%d：%s' % (failed_img_dict['url_serial_number'], failed_img_dict['img_number'], failed_img_dict['img_url']))
            print()
            
    if crawler.failed_img_list:
        f = open(r'ERROR.txt','w')
        for url_information_dict in crawler.failed_img_list:
            f.write(str(url_information_dict)+'\n')
        f.close()
        print('已将下载失败的图片信息保存至本程序所在目录下的ERROR.txt\n')

if __name__ == '__main__':
    
    start = time.perf_counter()
    
    crawler_for_img_of_ERRORtxt()
    
    end = time.perf_counter()
    
    print('任务执行共%.2f秒' % (end-start))
