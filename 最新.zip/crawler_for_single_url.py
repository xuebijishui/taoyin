from crawler_class import Crawler_class
import time
import os


def crawler_for_single_url(url=''):

    global crawler
    crawler = Crawler_class()
    
    if __name__ == '__main__':
        print('注意事项：')
        print('1、请确认目前是否可以通过%s访问桃隐，如不能，请在crawler_class.py的Crawler_class类的成员变量中修改domain_name的值为桃隐的最新域名' % crawler.domain_name)
        print('2、默认根目录为%s，如需修改，请在crawler_class.py的Crawler_class类的成员变量中修改default_root_path的值' % crawler.default_root_path)
        print('3、如果之前曾使用过此爬虫，请将生成的SAVED.txt放在本程序所在目录下，从而避免同一网页的重复爬取')
        url = input('请输入要爬取的网页的网址或编号：\n')
    
    url = crawler.correct_url(url)
    
    if url:
        
        if os.path.exists('SAVED.txt'):
            saved_file = open('SAVED.txt','r')
            saved_list = [img_serial_number[:-1] for img_serial_number in saved_file.readlines()]
            saved_file.close()
        else:
            saved_list = []
            
        if not crawler.is_already_saved(saved_list):
            
            html_source_code = crawler.get_html_source_code(url)
            '''
            我以为通过判断html_source_code是否为空就能知道是否请求成功，但万万没想到校园网太毒瘤了
            断网后仍然能获取网页源码，只不过是下面的源码
            <script>top.self.location.href='http://10.2.5.251/a79.htm?wlanuserip=10.4.18.17&wlanacname=NAS&ssid=Ruijie&nasip=10.2.4.1&mac=302432c506a7&t=wireless-v2-plain&url=http://c.taoy66.vip/thread-2884-1-1.html'</script>
            直接劫持了我的网页请求，但是我就不额外加判断的语句了，自己注意吧
            报错：
            File "D:\桌面\crawler_class.py", line 168, in get_html_title
            html_title = soup.find('title').string
            AttributeError: 'NoneType' object has no attribute 'string'
            源码不为空，且又没有<title>，很容易理解为何报错
            '''
            if html_source_code:
                
                if crawler.no_alert_error(html_source_code):
                    
                    html_title = crawler.get_html_title(html_source_code)
                    
                    if html_title:
                        
                        dir_path = crawler.make_dir()    #参数为self.sub_path,无需再传入html_title2884
                            
                        crawler.save_html_source_code(dir_path, html_title, html_source_code)
                        
                        html_type = crawler.get_html_type(html_source_code)
                            
                        new_html_source_code = crawler.make_new_html(html_source_code, html_type, url, html_title)
                        
                        if new_html_source_code:
                        
                            crawler.save_new_html(dir_path, html_title, new_html_source_code)
                                
                            img_list = crawler.get_img_urls(html_source_code, html_type, dir_path)    
                            #img_list内嵌套多个img_dict,每个img_dict都有'url_serial_number', 'img_url', 'img_number', 'dir_path'四个属性，
                            #即：帖子序号、图片网址、图片在本网页内的序号、图片下载所在路径
                            
                            if img_list:
                                '''
                                若第一次请求有失败的图片，则以追加的方式加入ERROR.txt中
                                在之后的请求中若有成功的图片，则从ERROR.txt中删除该图片的信息
                                '''
                                for run_time in range(1,3):    #每张图片最多请求十次    
                                    
                                    if run_time != 1:
                                        img_list = crawler.failed_img_list
                                    crawler.failed_img_list = []
                                    
                                    for img_number, img_dict in enumerate(img_list):  
                                        
                                        is_successful = crawler.get_and_save_img(img_dict, run_time)
                                        
                                        if run_time == 1 and not is_successful:
                                            crawler.add_failed_img_to_ERRORtxt(img_dict)
                                        if is_successful:    
                                            crawler.remove_successful_img_from_ERRORtxt(img_dict) 
                                            '''
                                            不管是否run_time=1,都要删除已成功的图片信息，
                                            因为上次程序可能半途中止运行，导致这次运行时run_time=1时，
                                            可能会使ERROR.txt中的一些图片下载成功,如果不删除这些图片信息，
                                            则run_time=2时还会重复下载
                                            '''

                                    if crawler.failed_img_list:
                                        
                                        print('%d张图片下载失败：' % len(crawler.failed_img_list))
                                        for failed_img_dict in crawler.failed_img_list:
                                            print('贴子%s-图%d：%s' % (failed_img_dict['url_serial_number'], failed_img_dict['img_number'], failed_img_dict['img_url']))
                                        print()
                                            
                                print('本网页共有%d张目标图片，成功下载%d张图片,失败%d张'% (crawler.img_amount, crawler.success_img_amount, crawler.img_amount-crawler.success_img_amount))
                                print('图片保存至%s\n' % dir_path)
                                if crawler.img_amount-crawler.success_img_amount != 0:
                                    print('失败文件已以追加的方式写入本程序所在目录下的ERROR.txt')
                                
                                with open(r'SAVED.txt','a+') as f:
                                    f.write(crawler.url_serial_number+'\n')


if __name__ == '__main__':

    start = time.perf_counter()
    
    crawler_for_single_url()
    
    end = time.perf_counter()
    
    print('任务执行共%.2f秒' % (end-start))